﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    internal class Configuration
    {
        public const string ConnectionString = @"Server=(localdb)\mssqllocaldb;Database=Hospital;Integrated Security=True";
    }
}
